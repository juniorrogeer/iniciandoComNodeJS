const express = require("express");
const bodyParser = require("body-parser");
var mysql = require("mysql");

var app = express();

//COnfiguração do Body Parser para imprimir dados do método post
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

//Roteamento

app.get("/", function (req, res) {
  app.use(express.static(__dirname + "/public")); //para organizar todos os arquivos dentro dessa página, permitindo que todo o projeto enxergue essa pasta e seu conteúdo
  res.sendFile(__dirname + "/index.html");
});

app.get("/formulario", function (req, res) {
  res.sendFile(__dirname + "/formulario.html");
});

app.post("/receber", function (req, res) {
  const nome = req.body.nome;
  const quantidade = req.body.quantidade;

  const sql = `INSERT INTO produto (nome, quantidade) VALUES ('${nome}', '${quantidade}')`;
  connection.query(sql, function (err) {
    if (err) {
      console.log(err);
    } else {
      res.redirect("/");
      console.log("Cadastro realizado com sucesso");
    }
  });

  //res.alert("Dados registrados");
  res.end();
});

//criação do servidor na porta 3000
app.listen(3000);

//Conexão com o Banco de Dados
var connection = mysql.createConnection({
  host: "localhost",
  port: "3307",
  user: "root",
  password: "",
  database: "projeto6",
});
