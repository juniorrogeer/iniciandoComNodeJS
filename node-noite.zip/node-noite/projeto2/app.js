const calculos = require('./calculo');

var soma = calculos.soma;

console.log(soma(5,5));
console.log(calculos.subtr(13,25));
console.log(calculos.multip(50,123));
console.log(calculos.divisao(13,8));