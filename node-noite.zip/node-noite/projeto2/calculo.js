function soma(a, b) {
    return a + b;
}

function subtr(c, d) {
    return c - d;
}

function multip(e, f) {
    return e * f;
}

function divisao(g, h) {
    return g / h;
}

module.exports = {
    soma, subtr, multip, divisao
}