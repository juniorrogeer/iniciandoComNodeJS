const express = require('express');

var app = express();

//criando rotas

app.get('/', function(req, res) {
    app.use(express.static(__dirname + '/public')); //para organizar todos os arquivos dentro dessa página, permitindo que todo o projeto enxergue essa pasta e seu conteúdo
    res.sendFile(__dirname + '/pagina.html');
})


app.get('/form', function(req, res) {
    res.sendFile(__dirname + '/formulario.html');
})

//criação do servidor na porta 3000
app.listen(3000);